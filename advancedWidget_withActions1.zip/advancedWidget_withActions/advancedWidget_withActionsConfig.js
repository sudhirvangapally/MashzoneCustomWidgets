/*
Copyright (c) 2010 - 2012 JackBe Corporation
Copyright (c) 2013 - 2017 Software AG, Darmstadt, Germany 
and/or Software AG USA Inc., Reston, VA, USA, and/or its
subsidiaries and/or its affiliates and/or their licensors.

Use, reproduction, transfer, publication or disclosure is
prohibited except as specifically provided for in your
License Agreement with Software AG.
*/
angular.module('advancedWidget_withActionsModule')
    
    .config(['dashboardProviderProvider', 'columnTypeConfigUrlServiceProvider', 
        function (dashboardProviderProvider, columnTypeConfigUrlServiceProvider) {
            dashboardProviderProvider.widget('advancedWidget_withActions', {
                title: 'advancedWidgetwithActions',
                category: 'customWidget',
                toolTip : {
                    "de":"Fortgeschrittenes Widget mit Actions",
                    "en":"advancedWidget_withActions"
                },
                actions: [
                    'assignData','filter',
                    'editName',
                    'hideHeader', 'hideBorder',
                    'autoRefresh',
                    'hLine',
                    'showDataType',
                    'actions', 'preselection',
                    'copy', 'paste', 'cut', 'delete',
                    'toTop', 'bringForward', 'sendBackward', 'toBack'],
                description: 'Advanced widget',
                templateUrl: 'widgets/customWidgets/advancedWidget_withActions/partials/advancedWidget_withActions.html',
                iconUrl: 'widgets/customWidgets/advancedWidget_withActions/assets/images/menu_icon_32x32.png',
                controller: 'advancedWidget_withActionsCtrl',
                resolve: {
                    widgetInterface: function(config, advancedWidget_withActionsDataService) {
                        config.widgetInterface = {
                            getDataMapping: advancedWidget_withActionsDataService.getDataMapping,
                            calculateCoordinateList: advancedWidget_withActionsDataService.calculateCoordinateList
                        };
                    }
                },
                actionResolver : {
                    resolveAction: function(actionKey){
                        if (actionKey == "showDataType") {
                            return {
                                name : 'Show datatype',
                                template : 'widgets/customWidgets/advancedWidget_withActions/partials/propertyPopup/showDataType.html'
                            };
                        }  
                    }
                },
                assignData: 'widgets/customWidgets/advancedWidget_withActions/partials/assignDataDialog/assignData.html',
                assignColumns: 'widgets/customWidgets/advancedWidget_withActions/partials/assignDataDialog/assignColumns.html',
                advancedProperties: 'widgets/customWidgets/advancedWidget_withActions/partials/assignDataDialog/advancedProperties.html',
                thresholdProperties: 'widgets/customWidgets/advancedWidget_withActions/partials/assignDataDialog/thresholdProperties.html',
                viewModeActions: ['deleteSelection', 'pause'],
                container: {
                    hideHeader: false,
                    hideBorder: false,
                    width: 200,
                    height: 100,
                    contentMinHeight: 60,
                    contentMinWidth: 60
                },
                actionFramework: {
                    getActionTriggers: function(widgetConfig, filter) {
                        var resources = filter('widgetResources');
                        var supportedTriggers = [{
                            key: 'onSelectionChange',
                            name: resources('ACTIONS_ON_SELECTION_CHANGE')
                        },{
                            key: 'onMouseEnter',
                            name: resources('ACTIONS_ON_MOUSE_OVER')
                        }];
                        return supportedTriggers;
                    }
                }
            });
            
            columnTypeConfigUrlServiceProvider.addColumnTypeUrlMapByWidget('advancedWidget_withActions',
                {
                    NUMERIC : ['widgets/customWidgets/advancedWidget_withActions/partials/assignDataDialog/columnTypeConfigTemplates', 'numeric.html'].join('/'),
                    DATE : ['widgets/customWidgets/advancedWidget_withActions/partials/assignDataDialog/columnTypeConfigTemplates', 'date.html'].join('/'),
                    TEXT : ['widgets/customWidgets/advancedWidget_withActions/partials/assignDataDialog/columnTypeConfigTemplates', 'text.html'].join('/')
                });
    }]);
