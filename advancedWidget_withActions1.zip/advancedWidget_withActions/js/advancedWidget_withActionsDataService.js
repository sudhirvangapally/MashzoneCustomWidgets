/*
Copyright (c) 2010 - 2012 JackBe Corporation
Copyright (c) 2013 - 2017 Software AG, Darmstadt, Germany 
and/or Software AG USA Inc., Reston, VA, USA, and/or its
subsidiaries and/or its affiliates and/or their licensors.

Use, reproduction, transfer, publication or disclosure is
prohibited except as specifically provided for in your
License Agreement with Software AG.
*/
angular.module('advancedWidget_withActionsModule')

.service('advancedWidget_withActionsDataService',['widgetDataService', 'formatNumberService', 'typeconstants','aggregationConstants', 
    function(widgetDataService, formatNumberService, typeconstants, aggregationConstants) {
        var createMappingColumnForInputColumnDrops = function(value, widgetDataService){
            if(!value || !value.column){
                return undefined;
            }
            var thAggregation = {type:value.column.aggregation.type};
            return widgetDataService.
                createDataMappingColumn(
                value.column.newName ,
                value.column.type,
                null,
                value.column.name,
                '',
                false,
                -1,
                true,
                thAggregation);
        };
        return {
            getDataMapping : function(item) {
                var dataMapping = {
                        columns: []
				},
				dataColumn;
				if(item.config && item.config.advancedWidget_withActionsCfg && item.config.advancedWidget_withActionsCfg.dataColumn) {
					dataColumn = item.config.advancedWidget_withActionsCfg.dataColumn;
				}

                if(dataColumn) {
                    var isNumericColumn =  dataColumn.type === typeconstants.NUMBER;
                    var format = isNumericColumn ? formatNumberService.
                            getFormatFromFormatKey(dataColumn.format) : undefined,
                        precision = isNumericColumn ? formatNumberService.
                            getPrecisionFromFormat(format) : undefined,
                        aggregation = isNumericColumn && dataColumn.aggregation ? {type: dataColumn.aggregation} : undefined,
                        datamappingCol = widgetDataService.
                            createDataMappingColumn(
                            dataColumn.name,
                            dataColumn.type,
                            null,
                            '',
                            dataColumn.newName || '',
                            dataColumn.round,
                            precision,
                            true,
                            aggregation);

                    dataMapping.columns.push(datamappingCol);
                }
                //Also add threshold columns
                if(item.config && item.config.advancedWidget_withActionsCfg && item.config.advancedWidget_withActionsCfg.thresholds){
                    for(var i = 0; i < item.config.advancedWidget_withActionsCfg.thresholds.length; i++){
                        var threshold = item.config.advancedWidget_withActionsCfg.thresholds[i];
                        var thColumn = createMappingColumnForInputColumnDrops(threshold.value, widgetDataService);
                        if(thColumn){
                            dataMapping.columns.push(thColumn);
                        }
                        var thColumn2 = createMappingColumnForInputColumnDrops(threshold.value2, widgetDataService);
                        if(thColumn2){
                            dataMapping.columns.push(thColumn2);
                        }
                    }
                }
                return dataMapping;
            },
            calculateCoordinateList : function(config) {
                var list = [];
                if(config.advancedWidget_withActionsCfg && config.advancedWidget_withActionsCfg.dataColumn){
                    list.push({
                        'name': config.advancedWidget_withActionsCfg.dataColumn.newName,
                        'type': config.advancedWidget_withActionsCfg.dataColumn.type
                    });
                }
                return list;
            }
        };
    }
    ]);