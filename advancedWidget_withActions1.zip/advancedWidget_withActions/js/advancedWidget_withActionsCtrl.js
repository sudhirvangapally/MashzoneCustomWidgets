/*
Copyright (c) 2010 - 2012 JackBe Corporation
Copyright (c) 2013 - 2017 Software AG, Darmstadt, Germany 
and/or Software AG USA Inc., Reston, VA, USA, and/or its
subsidiaries and/or its affiliates and/or their licensors.

Use, reproduction, transfer, publication or disclosure is
prohibited except as specifically provided for in your
License Agreement with Software AG.
*/
angular.module('advancedWidget_withActionsModule')

/**
 * Controller for your widget
 */
.controller('advancedWidget_withActionsCtrl',['$scope', 'filterService', 'formatDateService', 'formatNumberService', 'thresholdConstants',
        'thresholdService', 'actionConstants', 'actionService',
    function($scope, filterService, formatDateService, formatNumberService, thresholdConstants, thresholdService, actionConstants, actionService){
        var thresholds,
            data;
        
        $scope.formatDateService = formatDateService;
        $scope.formatNumberService = formatNumberService;
        $scope.selectedRow = '';
        $scope.column;
        $scope.rows;
        if(!data) {
            data = [''];
        }
        
        var initadvancedWidget_withActions = function() {
            if(!$scope.config){
                $scope.config = {};
            }
            if (!$scope.config.advancedWidget_withActionsCfg) {
                $scope.config.advancedWidget_withActionsCfg = {
                    showDataType: true,
                    thresholds: angular.copy(thresholdConstants.defaultThresholds)
                };
            }
        };
        initadvancedWidget_withActions();
        
        $scope.setConfig = function(config) {
            $scope.config = config;
        };

        $scope.setData = function(newData){
            thresholds = [];
            
            //check if current dataset contains selected value 
            var found = false;
            for(var i = 0; i < newData.rows.length; i++){
                var row = newData.rows[i];
                thresholds.push(getThreshold(newData, row));
                if(!row.values || row.values.length < 1){
                    continue;
                }
                var val = row.values[0];
                if(val === $scope.selectedRow) {
                    found = true;
                    break;
                }
            }
            if(!found) {
                filterService.onSelectionChange($scope.item.identifier, [], []);
                $scope.selectedRow = '';
            }
            data = newData;
            update();
        };

        var update = function() {
            var index = -1,
                i;
            $scope.rows = [];
            if(data && data.columns && $scope.config && $scope.config.advancedWidget_withActionsCfg && $scope.config.advancedWidget_withActionsCfg.dataColumn) {
                for(i = 0; i < data.columns.length; i++) {
                    if(data.columns[i].name === $scope.config.advancedWidget_withActionsCfg.dataColumn.newName) {
                        $scope.column = data.columns[i];
                        index = data.columns[i].idx;
                        break;
                    }
                }
            } else {
                $scope.column = '';
            }
            if(index > -1) {
                for(i = 0; i < data.rows.length; i++) {
                    $scope.rows.push(data.rows[i].values[index]);
                }
            } 
        }
        
        var getThreshold = function(data, row) {
            if($scope.config.advancedWidget_withActionsCfg.thresholds && data) {
                return thresholdService.getThresholdAreas($scope.config.advancedWidget_withActionsCfg.thresholds, data, row);
            }
        }
        
        $scope.onSelectionChange = function(row, triggerAction) {
            $scope.selectedRow = row;
            //ATTENTION, please keep in mind: in this case we have an Angular event listener (ngClick). If you use browser events (like element.on('mouseenter',function(e){}) 
            // you are outside of Angular's scope, so you have to manually call scope.$apply(); at the end of your listener.
            var coordinates = [$scope.config.advancedWidget_withActionsCfg.dataColumn.name];
            var values = [row];
            if(filterService.onSelectionChange($scope.item.identifier, coordinates, values) && triggerAction) {
                actionService.triggerAction($scope.item.identifier, actionConstants.actionTrigger.ON_SELECTION_CHANGE, coordinates, values);
            }
        };

        $scope.onMouseOver = function(row) {
            var coordinates = [$scope.config.advancedWidget_withActionsCfg.dataColumn.name];
            var values = [row];
            actionService.triggerAction($scope.item.identifier, actionConstants.actionTrigger.ON_MOUSE_ENTER, coordinates, values);
        }

        /**
         * 
         * @param cols
         * @param values
         * @param triggerAction There are situations (like e.g a data update in which
         */
        $scope.setSelection = function(cols, values, triggerAction) {
            if(!cols || !values || cols.length !== values.length) {
                return;
            }

            //check if the selection that should be set is available in the data set
            var value = '';
            if(values.length > 0){
                //we have to parse numeric columns before compare them
                if($scope.column.type === 'NUMERIC') {
                    for(var i = 0; i < data.rows.length; i++) {
                        if(parseFloat(data.rows[i].values[0]) === parseFloat(values[0])) {
                            value = data.rows[i].values[0];
                            break;
                        }
                    }
                } else {
                    for(var i = 0; i < data.rows.length; i++) {
                        if(data.rows[i].values[0] === values[0]) {
                            value = data.rows[i].values[0];
                            break;
                        }
                    }
                }
            }
            $scope.onSelectionChange(value, triggerAction!==false);
        };


        $scope.getRowColor = function(index, row) {
            if(thresholds[index]) {
                for(var i = 0; i < thresholds[index].length; i++) {
                    if(thresholds[index][i].containsValue(row)) {
                        return thresholds[index][i].colour;
                    }
                }
            }
            return 'transparent';
        }
        
        $scope.$on("onDeleteSelection", function(){
            $scope.selectedRow = '';
            if(filterService.onSelectionChange($scope.item.identifier, [], [], false)) {
                actionService.triggerAction($scope.item.identifier, actionConstants.actionTrigger.ON_SELECTION_CHANGE, [], []);
            }
        });
}]);