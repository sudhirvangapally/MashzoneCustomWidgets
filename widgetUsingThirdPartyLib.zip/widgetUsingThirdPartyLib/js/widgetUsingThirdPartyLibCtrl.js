/*
Copyright (c) 2010 - 2012 JackBe Corporation
Copyright (c) 2013 - 2017 Software AG, Darmstadt, Germany 
and/or Software AG USA Inc., Reston, VA, USA, and/or its
subsidiaries and/or its affiliates and/or their licensors.

Use, reproduction, transfer, publication or disclosure is
prohibited except as specifically provided for in your
License Agreement with Software AG.
*/
angular.module('widgetUsingThirdPartyLibModule')

/**
 * Controller for your widget
 */
.controller('widgetUsingThirdPartyLibCtrl',['$scope', function($scope){       	 
    
}])