/*
Copyright (c) 2010 - 2012 JackBe Corporation
Copyright (c) 2013 - 2017 Software AG, Darmstadt, Germany 
and/or Software AG USA Inc., Reston, VA, USA, and/or its
subsidiaries and/or its affiliates and/or their licensors.

Use, reproduction, transfer, publication or disclosure is
prohibited except as specifically provided for in your
License Agreement with Software AG.
*/
angular.module('widgetUsingThirdPartyLibModule')
    
    .config(['dashboardProviderProvider', 
        function (dashboardProviderProvider) {
            dashboardProviderProvider.widget('widgetUsingThirdPartyLib', {
                title: 'Third party lib',
                category: 'customWidget',
                toolTip : {
                    "de":"Third party lib",
                    "en":"Third party lib"
                },
                actions: ['editName',
                    'hLine','preselection',
                    'copy', 'paste', 'cut', 'delete',
                    'toTop', 'bringForward', 'sendBackward', 'toBack',
                    'hideHeader','hideBorder'],
                description: 'Widget using third party lib',
                templateUrl: 'widgets/customWidgets/widgetUsingThirdPartyLib/partials/widgetUsingThirdPartyLib.html',
                iconUrl: 'widgets/customWidgets/widgetUsingThirdPartyLib/assets/images/menu_icon_32x32.png',
                controller: 'widgetUsingThirdPartyLibCtrl',
                container: {
                    hideHeader: false,
                    hideBorder: false,
                    width: 200,
                    height: 150,
                    contentMinHeight: 60,
                    contentMinWidth: 60
                }
            });
    }]);
