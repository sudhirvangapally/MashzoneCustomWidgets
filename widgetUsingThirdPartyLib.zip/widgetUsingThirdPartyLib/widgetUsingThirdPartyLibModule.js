/*
Copyright (c) 2010 - 2012 JackBe Corporation
Copyright (c) 2013 - 2017 Software AG, Darmstadt, Germany 
and/or Software AG USA Inc., Reston, VA, USA, and/or its
subsidiaries and/or its affiliates and/or their licensors.

Use, reproduction, transfer, publication or disclosure is
prohibited except as specifically provided for in your
License Agreement with Software AG.
*/
/**
 * Important: add your third party library main module here: 
 * in this case I add "thirdPartyModule". The module name should be available in the documentation of the third party library
 */
angular.module('widgetUsingThirdPartyLibModule', ['prestoDashboard.dashboardProvider', 'thirdPartyModule']);