/*
Copyright (c) 2010 - 2012 JackBe Corporation
Copyright (c) 2013 - 2017 Software AG, Darmstadt, Germany 
and/or Software AG USA Inc., Reston, VA, USA, and/or its
subsidiaries and/or its affiliates and/or their licensors.

Use, reproduction, transfer, publication or disclosure is
prohibited except as specifically provided for in your
License Agreement with Software AG.
*/
angular.module('advancedWidgetModule')

/**
 * Controller for your widget
 */
.controller('advancedWidgetCtrl',['$scope', 'filterService', 'formatDateService', 'formatNumberService', 'thresholdConstants', 'thresholdService',
    function($scope, filterService, formatDateService, formatNumberService, thresholdConstants, thresholdService){
        var thresholds,
            data;
        
        $scope.formatDateService = formatDateService;
        $scope.formatNumberService = formatNumberService;
        $scope.selectedRow = '';
        $scope.column;
        $scope.rows;
        if(!data) {
            data = [''];
        }
        
        var initAdvancedWidget = function() {
            if(!$scope.config){
                $scope.config = {};
            }
            if (!$scope.config.advancedWidgetCfg) {
                $scope.config.advancedWidgetCfg = {
                    showDataType: true,
                    thresholds: angular.copy(thresholdConstants.defaultThresholds)
                };
            }
        };
        initAdvancedWidget();
        
        $scope.setConfig = function(config) {
            $scope.config = config;
        };

        $scope.setData = function(newData){
            thresholds = [];
            
            //check if current dataset contains selected value 
            var found = false;
            for(var i = 0; i < newData.rows.length; i++){
                var row = newData.rows[i];
                thresholds.push(getThreshold(newData, row));
                if(!row.values || row.values.length < 1){
                    continue;
                }
                var val = row.values[0];
                if(val === $scope.selectedRow) {
                    found = true;
                    break;
                }
            }
            if(!found) {
                filterService.onSelectionChange($scope.item.identifier, [], []);
                $scope.selectedRow = '';
            }
            data = newData;
            update();
        };

        var update = function() {
            var index = -1,
                i;
            $scope.rows = [];
            if(data && data.columns && $scope.config && $scope.config.advancedWidgetCfg && $scope.config.advancedWidgetCfg.dataColumn) {
                for(i = 0; i < data.columns.length; i++) {
                    if(data.columns[i] && data.columns[i].name === $scope.config.advancedWidgetCfg.dataColumn.newName) {
                        $scope.column = data.columns[i];
                        index = data.columns[i].idx;
                        break;
                    }
                }
            } else {
                $scope.column = '';
            }
            if(index > -1) {
                for(i = 0; i < data.rows.length; i++) {
                    $scope.rows.push(data.rows[i].values[index]);
                }
            } 
        }
        
        var getThreshold = function(data, row) {
            if($scope.config.advancedWidgetCfg.thresholds && data) {
                return thresholdService.getThresholdAreas($scope.config.advancedWidgetCfg.thresholds, data, row);
            }
        }
        
        $scope.onRowClick = function(row) {
            $scope.selectedRow = row;
            filterService.onSelectionChange($scope.item.identifier, [$scope.config.advancedWidgetCfg.dataColumn.name], [row]);
        }
        
        $scope.getRowColor = function(index, row) {
            if(thresholds[index]) {
                for(var i = 0; i < thresholds[index].length; i++) {
                    if(thresholds[index][i].containsValue(row)) {
                        return thresholds[index][i].colour;
                    }
                }
            }
            return 'transparent';
        }
        
        $scope.$on("onDeleteSelection", function(){
            $scope.selectedRow = '';
            filterService.onSelectionChange($scope.item.identifier, [], []);
        });
}]);