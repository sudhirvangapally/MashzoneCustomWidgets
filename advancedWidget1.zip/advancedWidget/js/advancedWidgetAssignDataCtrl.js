/*
Copyright (c) 2010 - 2012 JackBe Corporation
Copyright (c) 2013 - 2017 Software AG, Darmstadt, Germany 
and/or Software AG USA Inc., Reston, VA, USA, and/or its
subsidiaries and/or its affiliates and/or their licensors.

Use, reproduction, transfer, publication or disclosure is
prohibited except as specifically provided for in your
License Agreement with Software AG.
*/
angular.module('advancedWidgetModule')

/**
 * Controller for the Assign Data Dialog
 */
.controller('advancedWidgetAssignDataCtrl',['$scope', 'aggregationConstants', 'typeconstants', 'formatNumberService', 'numberFormatConstants', 'thresholdConstants',
    function($scope, aggregationConstants, typeconstants, formatNumberService, numberFormatConstants, thresholdConstants){
        $scope.showThresholdView = false;
        
        $scope.columnSelectionHandler = function(column) {
            $scope.showThresholdView = false;
            $scope.selectedColumn = column;
        };

        $scope.thresholdSelectionHandler = function() {
            $scope.showThresholdView = true;
        }
        /**
         * Is called after the user drops a column in the component configu
         * @param column
         */
        $scope.columnDropHandler = function(column) {
            column.newName = column.name;
            if(column.type === typeconstants.NUMBER){
                if(!column.aggregation) {
                    column.aggregation = aggregationConstants.AVG;
                }
                if(!column.format) {
                    column.format = numberFormatConstants.NUMERIC_FORMAT_PATTERNS[3];
                }
                column.round = true;
            } else if(column.type === typeconstants.DATE){
                column.format = "yyyy-MM-dd'T'HH:mm:ss";
            }
            $scope.columnSelectionHandler(column);
        };

        /**
         * Is called if the user clicks on the trash icon of a column
         * @param column The column that should be deleted
         */
        $scope.columnDeleted = function(column) {
            if ($scope.selectedColumn === column) {
                delete $scope.selectedColumn;
                $scope.itemClone.config.advancedWidgetCfg.thresholds = angular.copy(thresholdConstants.defaultThresholds);
            }
        };

        /**
         * Indicates if a column should be marked as selected
         * @param column The column to check
         * @returns {boolean} true if the column should be selected, otherwise false
         */
        $scope.selectColumn = function(column) {
            return $scope.showThresholdView ? false : $scope.selectedColumn === column;
        };
        
        $scope.columnSelectionHandler($scope.itemClone.config.advancedWidgetCfg.dataColumn);
    }]);